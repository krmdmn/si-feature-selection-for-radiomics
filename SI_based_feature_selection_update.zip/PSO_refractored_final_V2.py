"""
GBM survival analysis pipeline – BraTS (training + 20% holdout) and RHUH
(external validation).

Steps per run (``run_pipeline(k_best)``):
    1. Load BraTS + RHUH radiomics features for {t2,t1ce,t1,flair} x
       {tc, et, wt} and merge with clinical/survival info.
    2. 80/20 train-test split on BraTS, standardise on training fold,
       apply the same scaler to holdout and RHUH.
    3. Repeated stratified k-fold Lasso-Cox feature selection on the
       training fold; aggregate features by frequency.
    4. Particle-Swarm refinement of the candidate features.
    5. Append ``Age`` to the selected radiomics feature list.
    6. Bootstrap (n=200) hyperparameter search + bootstrap coefficient
       estimation.
    7. Final Coxnet fit on full training data; evaluate C-index on
       training, holdout and RHUH.
    8. Risk stratification by training-median linear predictor, KM
       curves + log-rank for the three cohorts.

The script can run as a single shot (one K) or sweep ``K_best`` from 2
to ``MAX_FEATURES``. Either way, every K's results land in
``RESULTS_CSV_PATH`` with metrics (C-index, p-values, selected
features, permutation importance, random seed).
"""

from __future__ import annotations

import statistics
from collections import Counter
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
from tqdm import tqdm

from lifelines.statistics import logrank_test

from ps_opt.feature_selection import ParticleSwarmFeatureSelectionCV
from sklearn.inspection import permutation_importance
from sklearn.linear_model import Lasso
from sklearn.model_selection import (
    GridSearchCV,
    KFold,
    RepeatedStratifiedKFold,
    train_test_split,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from sksurv.linear_model import CoxnetSurvivalAnalysis, CoxPHSurvivalAnalysis
from sksurv.metrics import concordance_index_censored
from sksurv.util import Surv


# =============================================================================
# Configuration
# =============================================================================

ROOT_DIR = Path(r"C:\Users\lenovo\Documents\SI_paper_final_may_2026")

BRATS_COMBINED_CSV = ROOT_DIR / "brats_combined.csv"
RHUH_COMBINED_CSV = ROOT_DIR / "rhuh_combined.csv"

# The combined CSVs have rows = patients and columns = features. The last
# N_CLINICAL_TAIL_COLS columns hold the clinical data (Age, OS, status);
# everything before them is radiomics. No PatientID column.
N_CLINICAL_TAIL_COLS = 3

# Split / CV / bootstrap
TEST_SPLIT_FRACTION = 0.2
RANDOM_SEED = 21
PSO_RANDOM_SEED = 22
BOOTSTRAP_RANDOM_SEED = 42

N_SPLITS = 5
N_REPEATS_FEATURE_SELECTION = 1
N_BOOTSTRAP = 200
PSO_N_PARTICLES = 30
PSO_MAX_ITER = 10

# Filtering
CORR_METHOD = "spearman"
CORR_THRESHOLD = 0.95
QUASI_CONST_THRESHOLD = 0.999

# Run mode / output
SINGLE_SHOT = True
MAX_FEATURES = 9
RESULTS_CSV_PATH = ROOT_DIR / "survival_analysis_results.csv"


# =============================================================================
# Result container
# =============================================================================


@dataclass
class PipelineResult:
    k_best: int

    # Log-rank p-values (median linear-predictor split)
    p_logrank_train: float
    p_logrank_holdout: float
    p_logrank_external_rhuh: float

    # C-index point estimates (Coxnet final model)
    c_index_train: float
    c_index_holdout: float
    c_index_external_rhuh: float

    # PSO selected features alone, fit on training, evaluated train+holdout
    c_index_pso_train: float
    c_index_pso_holdout: float

    # Selected features and permutation importance
    selected_features: list = field(default_factory=list)
    permutation_importance: list = field(default_factory=list)

    # Final number of features used in the model (incl. Age)
    feature_number: int = 0


# =============================================================================
# Data loading
# =============================================================================


def _split_features_clinical(csv_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Read a combined CSV (rows = patients, columns = features) and return
    (radiomics features, clinical). The last ``N_CLINICAL_TAIL_COLS`` columns
    are clinical (Age, OS, status); everything before them is radiomics."""
    df = pd.read_csv(csv_path)
    features = df.iloc[:, : -N_CLINICAL_TAIL_COLS]
    clinical = df.iloc[:, -N_CLINICAL_TAIL_COLS:]
    return features, clinical


def load_brats_features() -> pd.DataFrame:
    return _split_features_clinical(BRATS_COMBINED_CSV)[0]


def load_rhuh_features() -> pd.DataFrame:
    return _split_features_clinical(RHUH_COMBINED_CSV)[0]


def load_brats_clinical() -> pd.DataFrame:
    return _split_features_clinical(BRATS_COMBINED_CSV)[1]


def load_rhuh_clinical() -> pd.DataFrame:
    return _split_features_clinical(RHUH_COMBINED_CSV)[1]


def build_X_y(features: pd.DataFrame, clinical: pd.DataFrame
              ) -> tuple[pd.DataFrame, pd.DataFrame]:
    X = pd.concat(
        [features.reset_index(drop=True), clinical[["Age"]].reset_index(drop=True)],
        axis=1,
    )
    y = clinical[["OS", "status"]].reset_index(drop=True).astype({"OS": "float16"})
    return X, y


# =============================================================================
# Utilities
# =============================================================================


def drop_quasi_constant_and_duplicates(X: pd.DataFrame, thr: float) -> pd.DataFrame:
    n_rows = X.shape[0]
    quasi_const = [
        c for c in X.columns
        if (X[c].value_counts() / n_rows).sort_values(ascending=False).iloc[0] >= thr
    ]
    dup_cols = X.T[X.T.duplicated()].index.tolist()
    return X.drop(columns=set(quasi_const + dup_cols))


def drop_highly_correlated(X: pd.DataFrame, threshold: float, method: str) -> pd.DataFrame:
    corr = X.corr(method=method).abs()
    upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
    to_drop = [c for c in upper.columns if (upper[c] > threshold).any()]
    return X.drop(columns=to_drop)


# =============================================================================
# Feature selection
# =============================================================================


def lasso_cox_top_features(
    X_train: pd.DataFrame, y_struct, k_best: int
) -> tuple[list[str], list[float]]:
    """Fit CoxnetSurvivalAnalysis (l1_ratio=1) and return the top ``k_best``
    features by |coef| at the chosen alpha index."""
    model = CoxnetSurvivalAnalysis(l1_ratio=1.0)
    model.fit(X_train, y_struct)
    # Use the alpha column ~1% along the path (matches original behaviour).
    alpha_idx = round(len(model.coef_[0]) - 0.99 * len(model.coef_[0]))
    coefs = model.coef_[:, alpha_idx]
    ranked = (
        pd.DataFrame({"feature": X_train.columns, "coef": coefs, "abs": np.abs(coefs)})
        .sort_values("abs", ascending=False)
        .head(k_best)
    )
    return ranked["feature"].tolist(), ranked["coef"].tolist()


def repeated_fold_feature_selection(
    X: pd.DataFrame, y: pd.DataFrame, *, k_best: int, n_splits: int, n_repeats: int, seed: int
) -> pd.Index:
    """Run repeated stratified k-fold Lasso-Cox feature selection and return
    the candidate features ordered by frequency."""
    rskf = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=seed)
    selected_per_fold: list[list[str]] = []

    for train_idx, _ in rskf.split(X, y["status"]):
        X_tr_raw = X.iloc[train_idx].copy()
        y_tr = y.iloc[train_idx]

        scaler = StandardScaler()
        X_tr = pd.DataFrame(scaler.fit_transform(X_tr_raw), index=X_tr_raw.index, columns=X_tr_raw.columns)

        X_tr = drop_quasi_constant_and_duplicates(X_tr, QUASI_CONST_THRESHOLD)
        X_tr = drop_highly_correlated(X_tr, CORR_THRESHOLD, CORR_METHOD)

        struct_y = Surv.from_dataframe("status", "OS", y_tr.assign(status=y_tr["status"].astype(bool)))
        features, _coefs = lasso_cox_top_features(X_tr, struct_y, k_best)
        selected_per_fold.append(features)

    flat = [f for fold in selected_per_fold for f in fold]
    frequency = Counter(flat)
    ordered = [feat for feat, _ in frequency.most_common(len(frequency))]
    return pd.Index(ordered)


def pso_refine(
    X_train: pd.DataFrame, os_target: pd.Series, candidate_features: pd.Index, seed: int
) -> tuple[pd.Index, int]:
    """Refine the candidate feature subset with particle-swarm CV on a
    linear regression of OS time."""
    
    random_state_marker = np.random.randint(0, 115580)
    np.random.seed(seed)
    psocv = ParticleSwarmFeatureSelectionCV(
        n_particles=PSO_N_PARTICLES,
        estimator=Lasso,
        cv=3,
        scoring="neg_mean_squared_error",
        max_iter=PSO_MAX_ITER,
        n_jobs=-1,
        verbosity=0,
    )
    psocv.fit(pd.DataFrame(X_train[candidate_features]), pd.Series(os_target))
    refined = candidate_features[list(psocv.best_features_)]
    return refined, random_state_marker


# =============================================================================
# Bootstrap-based model fitting
# =============================================================================


def bootstrap_best_n_alphas(
    X: pd.DataFrame,
    y: pd.DataFrame,
    features: Sequence[str],
    *,
    n_boot: int,
    boot_seed: int,
    cv_seed: int,
) -> int:
    """Bootstrap GridSearchCV over ``CoxnetSurvivalAnalysis(n_alphas=...)``
    and return the most-frequently-selected ``n_alphas``."""
    param_grid = {"cox__n_alphas": [50, 100, 150, 200]}
    selected: list[int] = []
    rng_seed = boot_seed

    for _ in tqdm(range(n_boot), desc="Bootstrap n_alphas"):
        np.random.seed(rng_seed)
        idx = np.random.choice(len(X), len(X), replace=True)
        X_bs = X.iloc[idx]
        y_bs = y.iloc[idx].reset_index(drop=True)
        struct = Surv.from_dataframe("status", "OS", y_bs.assign(status=y_bs["status"].astype(bool)))

        pipe = Pipeline([("cox", CoxnetSurvivalAnalysis(l1_ratio=1.0))])
        grid = GridSearchCV(
            pipe, param_grid,
            cv=KFold(n_splits=5, shuffle=True, random_state=cv_seed),
            n_jobs=-1,
        )
        grid.fit(X_bs[features].reset_index(drop=True), struct)
        selected.append(grid.best_params_["cox__n_alphas"])

    return Counter(selected).most_common(1)[0][0]


def bootstrap_mean_coefficients(
    X: pd.DataFrame,
    y: pd.DataFrame,
    features: Sequence[str],
    *,
    n_boot: int,
    boot_seed: int,
    n_alphas: int,
) -> pd.Series:
    """Repeatedly fit ``CoxnetSurvivalAnalysis(n_alphas=n_alphas)`` on
    bootstrap resamples and return the per-feature mean coefficient."""
    coef_rows: list[pd.Series] = []
    for _ in range(n_boot):
        np.random.seed(boot_seed)
        idx = np.random.choice(len(X), len(X), replace=True)
        X_bs = X.iloc[idx]
        y_bs = y.iloc[idx].reset_index(drop=True)
        struct = Surv.from_dataframe("status", "OS", y_bs.assign(status=y_bs["status"].astype(bool)))

        model = CoxnetSurvivalAnalysis(l1_ratio=1.0, n_alphas=n_alphas)
        model.fit(X_bs[features].reset_index(drop=True), struct)
        coef_rows.append(
            pd.Series(model.coef_[:, -1], index=list(features))
        )
    return pd.DataFrame(coef_rows)[list(features)].mean()


# =============================================================================
# Evaluation helpers
# =============================================================================


def c_index(risk_scores: np.ndarray, y_struct) -> float:
    return float(concordance_index_censored(y_struct["status"], y_struct["OS"], risk_scores)[0])


# =============================================================================
# Risk stratification + log-rank
# =============================================================================


def km_logrank(
    durations: pd.Series,
    statuses: pd.Series,
    risk_label: np.ndarray,
) -> float:
    """Return the log-rank p-value comparing the two risk groups defined by
    ``risk_label`` (1 = low risk, 0 = high risk)."""
    high_mask = risk_label == 0
    low_mask = risk_label == 1
    os_high = durations[high_mask].tolist()
    os_low = durations[low_mask].tolist()
    event_high = statuses[high_mask].astype(bool)
    event_low = statuses[low_mask].astype(bool)

    return float(
        logrank_test(
            durations_A=os_high,
            durations_B=os_low,
            event_observed_A=event_high,
            event_observed_B=event_low,
        ).p_value
    )


# =============================================================================
# Pipeline
# =============================================================================


def run_pipeline(k_best: int) -> PipelineResult:
    print(f"\n===== Running survival pipeline with k_best = {k_best} =====")

    # ---- 1. Load data --------------------------------------------------------
    brats_features = load_brats_features()
    rhuh_features = load_rhuh_features()
    brats_clinical = load_brats_clinical()
    rhuh_clinical = load_rhuh_clinical()

    X_brats, y_brats = build_X_y(brats_features, brats_clinical)
    X_rhuh, y_rhuh = build_X_y(rhuh_features, rhuh_clinical)

    # ---- 2. Train/holdout split ---------------------------------------------
    X_train_raw, X_holdout_raw, y_train, y_holdout = train_test_split(
        X_brats, y_brats, test_size=TEST_SPLIT_FRACTION, random_state=RANDOM_SEED
    )
    X_train_raw = X_train_raw.reset_index(drop=True)
    X_holdout_raw = X_holdout_raw.reset_index(drop=True)
    y_train = y_train.reset_index(drop=True)
    y_holdout = y_holdout.reset_index(drop=True)

    scaler = StandardScaler()
    X_train = pd.DataFrame(
        scaler.fit_transform(X_train_raw), index=X_train_raw.index, columns=X_train_raw.columns
    )
    X_holdout = pd.DataFrame(
        scaler.transform(X_holdout_raw), index=X_holdout_raw.index, columns=X_holdout_raw.columns
    )
    X_external = pd.DataFrame(
        scaler.transform(X_rhuh), index=X_rhuh.index, columns=X_rhuh.columns
    )

    # Drop Age while running feature-selection CV (Age is appended manually later).
    X_train_no_age = X_train.iloc[:, :-1]

    # ---- 3. Repeated stratified k-fold Lasso-Cox feature selection ----------
    candidate_features = repeated_fold_feature_selection(
        X_train_no_age, y_train,
        k_best=k_best,
        n_splits=N_SPLITS,
        n_repeats=N_REPEATS_FEATURE_SELECTION,
        seed=RANDOM_SEED,
    )

    # ---- 4. PSO refinement + PSO-only C-index ------------------------------
    refined, _ = pso_refine(
        X_train, y_train["OS"], candidate_features, PSO_RANDOM_SEED
    )

    surv_train = Surv.from_dataframe(
        "status", "OS", y_train.assign(status=y_train["status"].astype(bool))
    )
    surv_holdout = Surv.from_dataframe(
        "status", "OS", y_holdout.assign(status=y_holdout["status"].astype(bool))
    )
    surv_external = Surv.from_dataframe(
        "status", "OS", y_rhuh.assign(status=y_rhuh["status"].astype(bool))
    )

    pso_model = CoxPHSurvivalAnalysis()
    pso_model.fit(X_train[refined], surv_train)
    c_idx_pso_train = c_index(pso_model.predict(X_train[refined]), surv_train)
    c_idx_pso_holdout = c_index(pso_model.predict(X_holdout[refined]), surv_holdout)
    print(f"PSO C-index train  : {c_idx_pso_train:.4f}")
    print(f"PSO C-index holdout: {c_idx_pso_holdout:.4f}")

    # ---- 5. Append Age -----------------------------------------------------
    selected = refined.append(pd.Index(["Age"]))

    # ---- 6. Bootstrap hyperparameter tuning + coefficient estimation -------
    best_n_alphas = bootstrap_best_n_alphas(
        X_train, y_train, selected.tolist(),
        n_boot=N_BOOTSTRAP, boot_seed=BOOTSTRAP_RANDOM_SEED, cv_seed=RANDOM_SEED,
    )
    print(f"Bootstrap selected n_alphas = {best_n_alphas}")

    _mean_coefs = bootstrap_mean_coefficients(
        X_train, y_train, selected.tolist(),
        n_boot=N_BOOTSTRAP, boot_seed=BOOTSTRAP_RANDOM_SEED, n_alphas=best_n_alphas,
    )

    # ---- 7. Final fit + C-index on all three cohorts -----------------------
    final_model = CoxnetSurvivalAnalysis(l1_ratio=1.0, n_alphas=best_n_alphas)
    final_model.fit(X_train[selected], surv_train)

    risk_train = final_model.predict(X_train[selected])
    risk_holdout = final_model.predict(X_holdout[selected])
    risk_external = final_model.predict(X_external[selected])

    c_idx_train = c_index(risk_train, surv_train)
    c_idx_holdout = c_index(risk_holdout, surv_holdout)
    c_idx_external = c_index(risk_external, surv_external)
    print(f"Final C-index train       : {c_idx_train:.3f}")
    print(f"Final C-index holdout     : {c_idx_holdout:.3f}")
    print(f"Final C-index external RHUH: {c_idx_external:.3f}")

    # ---- 9. Permutation importance on training ------------------------------
    perm = permutation_importance(
        final_model, X_train[selected], surv_train, n_repeats=200, random_state=RANDOM_SEED
    )
    perm_imp = perm["importances_mean"].tolist()

    # ---- 10. Risk stratification (median-of-training split) + KM/logrank ---
    threshold = statistics.median(risk_train)
    label_train = (risk_train < threshold).astype(int)
    label_holdout = (risk_holdout < threshold).astype(int)
    label_external = (risk_external < threshold).astype(int)

    p_train = km_logrank(y_train["OS"], y_train["status"], label_train)
    p_holdout = km_logrank(y_holdout["OS"], y_holdout["status"], label_holdout)
    p_external = km_logrank(y_rhuh["OS"], y_rhuh["status"], label_external)
    print(f"Log-rank p train / holdout / RHUH: {p_train:.4g} / {p_holdout:.4g} / {p_external:.4g}")

    # ---- 11. Pack results ---------------------------------------------------
    return PipelineResult(
        k_best=k_best,
        p_logrank_train=round(p_train, 4),
        p_logrank_holdout=round(p_holdout, 4),
        p_logrank_external_rhuh=round(p_external, 4),
        c_index_train=round(c_idx_train, 3),
        c_index_holdout=round(c_idx_holdout, 3),
        c_index_external_rhuh=round(c_idx_external, 3),
        c_index_pso_train=round(c_idx_pso_train, 3),
        c_index_pso_holdout=round(c_idx_pso_holdout, 3),
        selected_features=selected.tolist(),
        permutation_importance=[round(v, 4) for v in perm_imp],
        feature_number=len(selected),
    )


# =============================================================================
# Entry point
# =============================================================================


def main() -> None:
    if SINGLE_SHOT:
        k_values = [MAX_FEATURES]
    else:
        k_values = list(range(2, MAX_FEATURES + 1))

    rows: list[dict] = []
    for k in tqdm(k_values, desc="K sweep"):
        result = run_pipeline(k_best=k)
        row = asdict(result)
        row["selected_features"] = ";".join(row["selected_features"])
        row["permutation_importance"] = ";".join(str(v) for v in row["permutation_importance"])
        rows.append(row)

    # CSV column renames — fill in the blanks to taste.
    column_rename = {
        "k_best": "n_feature pool",
        "p_logrank_train": "",
        "p_logrank_holdout": "",
        "p_logrank_external_rhuh": "",
        "c_index_train": "",
        "c_index_holdout": "",
        "c_index_external_rhuh": "",
        "c_index_pso_train": "c_index_pso_train_RFs_only",
        "c_index_pso_holdout": "c_index_pso_holdout_RFs_only",
        "selected_features": "",
        "permutation_importance": "",
        "feature_number": "",
    }
    column_rename = {k: v for k, v in column_rename.items() if v}

    df = pd.DataFrame(rows).rename(columns=column_rename)
    df.to_csv(RESULTS_CSV_PATH, index=False)
    print(f"\nResults written to: {RESULTS_CSV_PATH}")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()

