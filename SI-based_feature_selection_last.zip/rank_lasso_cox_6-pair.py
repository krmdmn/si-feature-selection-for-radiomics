# -*- coding: utf-8 -*-
"""
Created on Sat Mar 22 10:42:51 2025

@author: krm
"""

import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
import numpy as np

# Maximum number of radiomics features to select (clinical 'Age' will be added later)
max_feature_count = 6

# Flag to run only one iteration or loop over multiple feature selections
single_shot = True  # just for 9-pair result
#single_shot = False  # for 2-pair to 9-pair result

def survival_analysis_pipeline(num_top_features=3):
    # If True, later drop extra radiomics features based on correlation (not applied here)
    drop_radiomics_limit = False

    # ------------------------------
    # Load and Prepare Datasets
    # ------------------------------
    # Load BRATS and RHUH data
    brats_df = pd.read_csv('brats_data.csv')
    rhuh_df = pd.read_csv('rhuh_data.csv')

    # For BRATS, use all columns except the first and last three
    features_brats = brats_df.iloc[:, 1:-3]
    outcomes_brats = brats_df.iloc[:, -3:]
    outcomes_brats = outcomes_brats.astype({'OS': 'float16'})

    # For RHUH, use all columns except the first and last two
    features_rhuh = rhuh_df.iloc[:, 1:-2]
    outcomes_rhuh = rhuh_df.iloc[:, -2:]
    outcomes_rhuh = outcomes_rhuh.astype({'OS': 'float16'})

    # Here we use only BRATS data for the initial analysis
    features_combined = pd.concat([features_brats], axis=0).reset_index(drop=True)
    outcomes_combined = pd.concat([outcomes_brats], axis=0).reset_index(drop=True)
    X = features_combined
    y = outcomes_combined

    # ------------------------------
    # Train-Test Split and Scaling
    # ------------------------------
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=21)
    X_train = X_train.reset_index(drop=True)
    y_train = y_train.reset_index(drop=True)
    X_test = X_test.reset_index(drop=True)
    y_test = y_test.reset_index(drop=True)

    # Copy training data for further processing
    features_train = X_train.copy().reset_index(drop=True)
    outcomes_train = y_train.copy().reset_index(drop=True)

    # For cross-validation, remove the last column (e.g. Age) from training features
    features_train_cv = features_train.iloc[:, :-1].copy()
    outcomes_train_cv = outcomes_train.copy()

    features_test = X_test.copy().reset_index(drop=True)
    outcomes_test = y_test.copy().reset_index(drop=True)

    # Scale the training set
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    scaled_train = scaler.fit_transform(features_train)
    features_train.loc[:, :] = scaled_train

    # Scale the test set using the same scaler
    test_features_unscaled = features_test.copy()
    scaled_test = scaler.transform(test_features_unscaled)
    features_test.loc[:, :] = scaled_test

    # Scale the external RHUH data for validation
    external_features_rhuh = features_rhuh.copy()
    scaled_external = scaler.transform(external_features_rhuh)
    features_rhuh.loc[:, :] = scaled_external

    # ------------------------------
    # Cross-Validation for Feature Selection
    # ------------------------------
    from sklearn.model_selection import RepeatedStratifiedKFold
    n_splits = 5
    n_repeats = 1
    random_state_cv = 21
    rskf = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=random_state_cv)
    rskf2 = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=2, random_state=random_state_cv)

    cv_selected_features_list = []
    cv_feature_coefficients = []
    cv_train_cindices = []
    cv_val_cindices = []

    for cv_train_idx, cv_val_idx in rskf.split(features_train_cv, outcomes_train_cv["status"]):
        cv_train_features = features_train_cv.iloc[cv_train_idx].copy()
        cv_val_features = features_train_cv.iloc[cv_val_idx].copy()
        cv_train_outcomes = outcomes_train_cv.iloc[cv_train_idx].copy()
        cv_val_outcomes = outcomes_train_cv.iloc[cv_val_idx].copy()

        # Create structured survival data for the training fold
        cv_train_structured = pd.DataFrame({
            'time': cv_train_outcomes["OS"],
            'event': cv_train_outcomes["status"]
        })
        from sksurv.util import Surv
        structured_cv_train = Surv.from_dataframe('event', 'time', cv_train_structured)

        # Scale training and validation splits for CV
        cv_scaler = StandardScaler()
        cv_train_features.loc[:, :] = cv_scaler.fit_transform(cv_train_features)
        cv_val_features.loc[:, :] = cv_scaler.transform(cv_val_features)

        # Remove constant features with VarianceThreshold
        from sklearn.feature_selection import VarianceThreshold
        selector = VarianceThreshold(threshold=0)
        selector.fit(cv_train_features)
        features_to_keep = selector.get_support()
        constant_columns = cv_train_features.columns[~features_to_keep]

        # Remove quasi-constant features
        quasi_constant_columns = []
        num_rows = cv_train_features.shape[0]
        for col in cv_train_features.columns:
            top_val_ratio = (cv_train_features[col].value_counts() / num_rows).sort_values(ascending=False).values[0]
            if top_val_ratio >= 0.999:
                quasi_constant_columns.append(col)
        dup_columns = cv_train_features.T[cv_train_features.T.duplicated()].index.tolist()
        cv_train_features = cv_train_features.drop(columns=quasi_constant_columns + dup_columns)

        # Remove highly correlated features (correlation > 0.95)
        corr_matrix = cv_train_features.corr(method='spearman').abs()
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        high_corr_features = [col for col in upper_tri.columns if any(upper_tri[col] > 0.95)]
        cv_train_features = cv_train_features.drop(columns=high_corr_features)

        # Fit a Coxnet model for survival analysis (Lasso Cox)
        from sksurv.linear_model import CoxnetSurvivalAnalysis
        from sklearn import set_config
        set_config(display="text")
        coxnet_model_cv = CoxnetSurvivalAnalysis(l1_ratio=1.0)
        coxnet_model_cv.fit(cv_train_features, structured_cv_train)

        # Select coefficients from a near-final iteration (index selection as in original code)
        coef_index = round(len(coxnet_model_cv.coef_[0,]) - 0.99 * len(coxnet_model_cv.coef_[0,]))
        coefficients = coxnet_model_cv.coef_[:, coef_index]
        nonzero_mask = coefficients != 0
        cv_selected_features = cv_train_features.columns[nonzero_mask]

        # Create a DataFrame for feature coefficients
        features_df = pd.DataFrame({
            'Feature': cv_train_features.columns,
            'Coefficient': coefficients,
            'Absolute_Coefficient': np.abs(coefficients)
        })
        sorted_features = features_df.sort_values(by='Absolute_Coefficient', ascending=False)
        top_cv_features = sorted_features.head(num_top_features)
        top_coefficients = top_cv_features['Coefficient'].tolist()
        top_feature_names = top_cv_features['Feature'].tolist()
        cv_feature_series = pd.Series(top_coefficients, index=top_feature_names)

        cv_selected_features_list.append(cv_feature_series.index)
        cv_feature_coefficients.append(cv_feature_series.copy())

    # ------------------------------
    # Feature Ranking (Replaces PSO Refinement)
    # ------------------------------
    from collections import Counter
    # Flatten the list of lists from CV into a single list of features
    all_cv_features = [feature for feature_list in cv_selected_features_list for feature in feature_list]
    # Calculate the frequency of each feature name
    feature_frequency = Counter(all_cv_features)
    XX_feature_frequency_xx = feature_frequency  # Can be used later for analysis

    # Ranking parameters
    ranking_on = True  # Toggle ranking mode on/off
    selec_fno = num_top_features  # Number of top features to select when ranking is on

    if ranking_on:
        top_features = feature_frequency.most_common(selec_fno)
    else:
        top_features = feature_frequency.most_common(len(feature_frequency))

    # Extract the top feature names and create a pandas Index
    top_feature_names = [feature for feature, _ in top_features]
    final_selected_features = pd.Index(top_feature_names)
    selected_features_backup = final_selected_features.copy()

    # Append clinical feature 'Age'
    final_selected_features = final_selected_features.append(pd.Index(['Age']))

    # ------------------------------
    # Internal Cross-Validation for Model Evaluation
    # ------------------------------
    cv_train_cindices = []
    cv_val_cindices = []

    for cv_train_idx, cv_val_idx in rskf2.split(features_train, outcomes_train_cv["status"]):
        cv_train_set = features_train.iloc[cv_train_idx].copy()
        cv_val_set = features_train.iloc[cv_val_idx].copy()
        cv_train_outcomes_set = outcomes_train_cv.iloc[cv_train_idx].copy()
        cv_val_outcomes_set = outcomes_train_cv.iloc[cv_val_idx].copy()

        cv_train_structured = pd.DataFrame({
            'time': cv_train_outcomes_set["OS"],
            'event': cv_train_outcomes_set["status"]
        })
        structured_cv_train = Surv.from_dataframe('event', 'time', cv_train_structured)

        cv_scaler = StandardScaler()
        cv_train_set.loc[:, :] = cv_scaler.fit_transform(cv_train_set)
        cv_val_set.loc[:, :] = cv_scaler.transform(cv_val_set)

        from sksurv.linear_model import CoxnetSurvivalAnalysis
        coxnet_model_cv = CoxnetSurvivalAnalysis(l1_ratio=1.0)
        coxnet_model_cv.fit(cv_train_set[final_selected_features], structured_cv_train)
        predict_train_cv = coxnet_model_cv.predict(cv_train_set[final_selected_features])
        from sksurv.metrics import concordance_index_censored
        train_cindex = concordance_index_censored(structured_cv_train["event"],
                                                  structured_cv_train["time"],
                                                  predict_train_cv)[0]
        cv_train_cindices.append(train_cindex)

        cv_val_structured = pd.DataFrame({
            'time': cv_val_outcomes_set["OS"],
            'event': cv_val_outcomes_set["status"]
        })
        structured_cv_val = Surv.from_dataframe('event', 'time', cv_val_structured)
        predict_val_cv = coxnet_model_cv.predict(cv_val_set[final_selected_features])
        val_cindex = concordance_index_censored(structured_cv_val["event"],
                                                structured_cv_val["time"],
                                                predict_val_cv)[0]
        cv_val_cindices.append(val_cindex)

    mean_cv_train_cindex = np.mean(cv_train_cindices)
    mean_cv_val_cindex = np.mean(cv_val_cindices)

    # ------------------------------
    # Bootstrap for Hyperparameter Tuning (GridSearchCV)
    # ------------------------------
    features_train_boot = features_train.copy()
    outcomes_train_boot = outcomes_train.copy()
    train_structured_boot = pd.DataFrame({
        'time': outcomes_train_boot["OS"],
        'event': outcomes_train_boot["status"]
    })
    boot_outcomes = train_structured_boot.copy().reset_index(drop=True)
    n_bootstrap = 200
    best_model_params_list = []

    from tqdm import tqdm
    from sklearn.model_selection import GridSearchCV, KFold
    from sklearn.pipeline import Pipeline
    for i in tqdm(range(n_bootstrap)):
        np.random.seed(42)
        resample_indices = np.random.choice(len(features_train_boot), len(features_train_boot), replace=True)
        resample_times = boot_outcomes["time"][resample_indices]
        resample_events = boot_outcomes["event"][resample_indices]
        resampled_features = features_train_boot.iloc[resample_indices]
        resample_structured = pd.DataFrame({
            'time': resample_times,
            'event': resample_events
        })
        structured_resample = Surv.from_dataframe('event', 'time', resample_structured)

        pipeline = Pipeline([
            ('cox', CoxnetSurvivalAnalysis(l1_ratio=1.0))
        ])
        param_grid = {
            'cox__n_alphas': [1, 5, 10, 50, 100]
        }
        cv_kfold = KFold(n_splits=5, shuffle=True, random_state=21)
        grid_search = GridSearchCV(pipeline, param_grid, cv=cv_kfold, n_jobs=-1)
        grid_search.fit(resampled_features[final_selected_features], structured_resample)
        best_model_params_list.append(grid_search.best_params_)

    # Determine the most common hyperparameter for n_alphas
    best_n_alphas_list = [params['cox__n_alphas'] for params in best_model_params_list]
    from collections import Counter
    param_counts = Counter(best_n_alphas_list)
    top_n_alphas, _ = param_counts.most_common(1)[0]

    # ------------------------------
    # Bootstrap for Coefficient Estimation
    # ------------------------------
    features_train_boot = features_train.copy()
    outcomes_train_boot = outcomes_train.copy()
    train_structured_boot = pd.DataFrame({
        'time': outcomes_train_boot["OS"],
        'event': outcomes_train_boot["status"]
    })
    boot_outcomes = train_structured_boot.copy().reset_index(drop=True)
    n_bootstrap = 200
    bootstrap_coef_list = []
    for i in range(n_bootstrap):
        np.random.seed(42)
        resample_indices = np.random.choice(len(features_train_boot), len(features_train_boot), replace=True)
        resample_times = boot_outcomes["time"][resample_indices]
        resample_events = boot_outcomes["event"][resample_indices]
        resampled_features = features_train_boot.iloc[resample_indices]
        resample_structured = pd.DataFrame({
            'time': resample_times,
            'event': resample_events
        })
        structured_resample = Surv.from_dataframe('event', 'time', resample_structured)
        coxnet_model_boot = CoxnetSurvivalAnalysis(l1_ratio=1.0, n_alphas=top_n_alphas)
        coxnet_model_boot.fit(resampled_features[final_selected_features], structured_resample)
        coef_series = pd.Series(coxnet_model_boot.coef_[:, -1],
                                index=resampled_features[final_selected_features].columns)
        bootstrap_coef_list.append(coef_series.copy())

    combined_coef_df = pd.DataFrame(bootstrap_coef_list)
    # Ensure the ranking order is used for coefficient analysis
    filtered_coef_df = combined_coef_df[list(final_selected_features)]
    mean_coef_top_features = filtered_coef_df.mean()
    print(mean_coef_top_features)

    # ------------------------------
    # Final Model Training and Evaluation
    # ------------------------------
    final_train_features = features_train
    final_train_outcomes = outcomes_train
    final_test_features = features_test
    final_test_outcomes = outcomes_test
    external_test_features = features_rhuh
    external_test_outcomes = outcomes_rhuh

    final_train_structured = pd.DataFrame({
        'time': final_train_outcomes["OS"],
        'event': final_train_outcomes["status"]
    })
    structured_final_train = Surv.from_dataframe('event', 'time', final_train_structured)

    final_test_structured = pd.DataFrame({
        'time': final_test_outcomes["OS"],
        'event': final_test_outcomes["status"]
    })
    structured_final_test = Surv.from_dataframe('event', 'time', final_test_structured)

    external_test_structured = pd.DataFrame({
        'time': external_test_outcomes["OS"],
        'event': external_test_outcomes["status"]
    })
    structured_external_test = Surv.from_dataframe('event', 'time', external_test_structured)

    final_coxnet_model = CoxnetSurvivalAnalysis(l1_ratio=1.0, n_alphas=top_n_alphas)
    final_coxnet_model.fit(final_train_features[final_selected_features], structured_final_train)
    final_train_predictions = final_coxnet_model.predict(final_train_features[final_selected_features])
    train_cindex = concordance_index_censored(structured_final_train["event"],
                                              structured_final_train["time"],
                                              final_train_predictions)[0]
    print('c-index (Train):', train_cindex)
    train_cindex_value = train_cindex

    # Bootstrap on training predictions for confidence intervals
    boot_train = structured_final_train.copy()
    n_bootstrap = 200
    bootstrap_train_cindices = np.zeros(n_bootstrap)
    bootstrap_oob_cindices = np.zeros(n_bootstrap)
    for i in range(n_bootstrap):
        resample_indices = np.random.choice(len(final_train_predictions), len(final_train_predictions), replace=True)
        resample_pred = final_train_predictions[resample_indices]
        resample_time = boot_train["time"][resample_indices]
        resample_event = boot_train["event"][resample_indices]
        all_indices = np.arange(len(final_train_predictions))
        oob_indices = np.setdiff1d(all_indices, resample_indices)
        resample_pred_oob = final_train_predictions[oob_indices]
        resample_time_oob = boot_train["time"][oob_indices]
        resample_event_oob = boot_train["event"][oob_indices]
        bootstrap_train_cindices[i] = concordance_index_censored(
            resample_event, resample_time, resample_pred)[0]
        bootstrap_oob_cindices[i] = concordance_index_censored(
            resample_event_oob, resample_time_oob, resample_pred_oob)[0]
    oob_ci_bounds_mean = np.mean(bootstrap_oob_cindices)

    # Evaluate on test set
    final_test_predictions = final_coxnet_model.predict(final_test_features[final_selected_features])
    test_cindex = concordance_index_censored(structured_final_test["event"],
                                             structured_final_test["time"],
                                             final_test_predictions)[0]
    print('c-index (Test):', test_cindex)
    test_cindex_value = test_cindex

    # Evaluate on external RHUH dataset
    external_test_predictions = final_coxnet_model.predict(external_test_features[final_selected_features])
    external_cindex = concordance_index_censored(structured_external_test["event"],
                                                 structured_external_test["time"],
                                                 external_test_predictions)[0]
    print('c-index (External Test):', external_cindex)
    external_cindex_value = external_cindex

    # ------------------------------
    # Survival Logrank Test
    # ------------------------------
    import statistics
    median_risk = statistics.median(final_train_predictions)
    train_labels = [int(score < median_risk) for score in final_train_predictions]
    test_labels = [int(score < median_risk) for score in final_test_predictions]
    external_labels = [int(score < median_risk) for score in external_test_predictions]

    # Logrank test for training set
    os_train_high = final_train_outcomes["OS"][np.array(train_labels) == 0].tolist()
    os_train_low = final_train_outcomes["OS"][np.array(train_labels) == 1].tolist()
    from lifelines.statistics import logrank_test
    train_logrank = logrank_test(os_train_high, os_train_low)
    train_logrank.print_summary()
    train_p_value = train_logrank.p_value

    # Logrank test for test set
    os_test_high = final_test_outcomes["OS"][np.array(test_labels) == 0].tolist()
    os_test_low = final_test_outcomes["OS"][np.array(test_labels) == 1].tolist()
    test_logrank = logrank_test(os_test_high, os_test_low)
    test_logrank.print_summary()
    test_p_value = test_logrank.p_value

    # Logrank test for external set
    os_external_high = external_test_outcomes["OS"][np.array(external_labels) == 0].tolist()
    os_external_low = external_test_outcomes["OS"][np.array(external_labels) == 1].tolist()
    external_logrank = logrank_test(os_external_high, os_external_low)
    external_logrank.print_summary()
    external_p_value = external_logrank.p_value

    print(f"Train p-value: {train_p_value}, Test p-value: {test_p_value}, External p-value: {external_p_value}")

    # ------------------------------
    # Return Summary Results
    # ------------------------------
    return (num_top_features, train_p_value, test_p_value,
            external_p_value, round(train_cindex_value, 2),
            round(test_cindex_value, 2), round(external_cindex_value, 2),
            round(mean_cv_train_cindex, 2), round(mean_cv_val_cindex, 2),
            round(oob_ci_bounds_mean, 2), final_selected_features, len(final_selected_features))

# ------------------------------
# Run the Analysis Pipeline
# ------------------------------
results_list = []
if single_shot:
    for i in range(max_feature_count, max_feature_count + 1):
        results_list.append(survival_analysis_pipeline(num_top_features=i))
else:
    for i in tqdm(range(2, max_feature_count + 1)):
        results_list.append(survival_analysis_pipeline(num_top_features=i))

# Define the column names for the DataFrame
columns = [
    "features_pair",
    "train_p_value",
    "test_p_value",
    "external_p_value",
    "train_cindex",
    "test_cindex",
    "external_cindex",
    "mean_cv_train_cindex",
    "mean_cv_val_cindex",
    "oob_ci_bounds_mean",
    "final_selected_features",
    "feature_number"
]

# Create the DataFrame with the column headers on top and corresponding values below
results_df = pd.DataFrame(results_list, columns=columns)

# Display the DataFrame
print(results_df)

results_df.to_csv("output_rank.csv", index=False)
# results_df.to_csv("output_Rank_2_9.csv", index=False)